
import React, { useState } from 'react';
import Display from './components/Display';
import Button from './components/Button';

type Operator = '+' | '-' | '×' | '÷';

const App: React.FC = () => {
  const [displayValue, setDisplayValue] = useState<string>('0');
  const [firstOperand, setFirstOperand] = useState<number | null>(null);
  const [operator, setOperator] = useState<Operator | null>(null);
  const [waitingForSecondOperand, setWaitingForSecondOperand] = useState<boolean>(false);

  const calculate = (first: number, second: number, op: Operator): number => {
    switch (op) {
      case '+':
        return first + second;
      case '-':
        return first - second;
      case '×':
        return first * second;
      case '÷':
        return first / second;
      default:
        return second;
    }
  };

  const handleDigitClick = (digit: string) => {
    if (waitingForSecondOperand) {
      setDisplayValue(digit);
      setWaitingForSecondOperand(false);
    } else {
      setDisplayValue(displayValue === '0' ? digit : displayValue + digit);
    }
  };

  const handleDecimalClick = () => {
    if (waitingForSecondOperand) {
        setDisplayValue('0.');
        setWaitingForSecondOperand(false);
        return;
    }
    if (!displayValue.includes('.')) {
      setDisplayValue(displayValue + '.');
    }
  };

  const handleOperatorClick = (nextOperator: Operator) => {
    const inputValue = parseFloat(displayValue);

    if (operator && firstOperand !== null && !waitingForSecondOperand) {
        const result = calculate(firstOperand, inputValue, operator);
        setDisplayValue(String(result));
        setFirstOperand(result);
    } else {
        setFirstOperand(inputValue);
    }

    setWaitingForSecondOperand(true);
    setOperator(nextOperator);
  };

  const handleEqualsClick = () => {
    const inputValue = parseFloat(displayValue);
    if (operator && firstOperand !== null) {
      const result = calculate(firstOperand, inputValue, operator);
      setDisplayValue(String(result));
      setFirstOperand(null);
      setOperator(null);
      setWaitingForSecondOperand(true);
    }
  };

  const handleClearClick = () => {
    setDisplayValue('0');
    setFirstOperand(null);
    setOperator(null);
    setWaitingForSecondOperand(false);
  };

  const handlePlusMinusClick = () => {
    setDisplayValue(String(parseFloat(displayValue) * -1));
  };

  const handlePercentClick = () => {
    setDisplayValue(String(parseFloat(displayValue) / 100));
  };

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center">
      <div className="w-full max-w-xs sm:max-w-sm">
        <div className="bg-black rounded-3xl shadow-lg p-4 sm:p-6 space-y-4">
          <Display value={displayValue} />
          <div className="grid grid-cols-4 gap-2 sm:gap-4">
            {/* Row 1 */}
            <Button onClick={handleClearClick} className="bg-gray-400 text-black">{displayValue !== '0' || firstOperand !== null ? 'C' : 'AC'}</Button>
            <Button onClick={handlePlusMinusClick} className="bg-gray-400 text-black">+/-</Button>
            <Button onClick={handlePercentClick} className="bg-gray-400 text-black">%</Button>
            <Button onClick={() => handleOperatorClick('÷')} className={`bg-orange-500 text-white ${operator === '÷' && waitingForSecondOperand ? 'ring-2 ring-white ring-inset' : ''}`}>÷</Button>
            
            {/* Row 2 */}
            <Button onClick={() => handleDigitClick('7')}>7</Button>
            <Button onClick={() => handleDigitClick('8')}>8</Button>
            <Button onClick={() => handleDigitClick('9')}>9</Button>
            <Button onClick={() => handleOperatorClick('×')} className={`bg-orange-500 text-white ${operator === '×' && waitingForSecondOperand ? 'ring-2 ring-white ring-inset' : ''}`}>×</Button>

            {/* Row 3 */}
            <Button onClick={() => handleDigitClick('4')}>4</Button>
            <Button onClick={() => handleDigitClick('5')}>5</Button>
            <Button onClick={() => handleDigitClick('6')}>6</Button>
            <Button onClick={() => handleOperatorClick('-')} className={`bg-orange-500 text-white ${operator === '-' && waitingForSecondOperand ? 'ring-2 ring-white ring-inset' : ''}`}>-</Button>

            {/* Row 4 */}
            <Button onClick={() => handleDigitClick('1')}>1</Button>
            <Button onClick={() => handleDigitClick('2')}>2</Button>
            <Button onClick={() => handleDigitClick('3')}>3</Button>
            <Button onClick={() => handleOperatorClick('+')} className={`bg-orange-500 text-white ${operator === '+' && waitingForSecondOperand ? 'ring-2 ring-white ring-inset' : ''}`}>+</Button>

            {/* Row 5 */}
            <Button onClick={() => handleDigitClick('0')} className="col-span-2">0</Button>
            <Button onClick={handleDecimalClick}>.</Button>
            <Button onClick={handleEqualsClick} className="bg-orange-500 text-white">=</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
