
import React from 'react';

interface ButtonProps {
  onClick: () => void;
  children: React.ReactNode;
  className?: string;
}

const Button: React.FC<ButtonProps> = ({ onClick, children, className }) => {
  const baseClasses = "text-white text-3xl font-medium rounded-full focus:outline-none focus:ring-2 focus:ring-gray-500 transition-colors duration-200 aspect-square flex items-center justify-center";
  const numberClasses = "bg-gray-700 hover:bg-gray-600 active:bg-gray-500";

  // Check if a specific background color class is provided, otherwise use the default number color.
  const hasBgColor = className?.includes('bg-');
  const finalClasses = `${baseClasses} ${hasBgColor ? '' : numberClasses} ${className || ''}`;

  return (
    <button onClick={onClick} className={finalClasses}>
      {children}
    </button>
  );
};

export default Button;
