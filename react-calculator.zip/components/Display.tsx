
import React from 'react';

interface DisplayProps {
  value: string;
}

const Display: React.FC<DisplayProps> = ({ value }) => {
  // Simple font scaling logic
  const getFontSize = (length: number) => {
    if (length > 16) return 'text-3xl';
    if (length > 10) return 'text-4xl';
    if (length > 7) return 'text-5xl';
    return 'text-6xl';
  };
  
  const formattedValue = new Intl.NumberFormat('en-US', {
    maximumFractionDigits: 10,
  }).format(Number(value))

  return (
    <div className="bg-black text-white w-full h-24 rounded-lg flex items-end justify-end p-4 mb-4">
      <h1 className={`font-light whitespace-nowrap overflow-hidden ${getFontSize(value.length)}`}>
        {value}
      </h1>
    </div>
  );
};

export default Display;
